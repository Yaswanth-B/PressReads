// import logo from './logo.svg';
import './App.css';
import NameForm from './form';
function App() {
  return (
    <div className="App">
      <NameForm/>
    </div>
  );
}

export default App;
