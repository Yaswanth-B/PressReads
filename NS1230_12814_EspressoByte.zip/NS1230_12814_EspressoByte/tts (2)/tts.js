let speech = new SpeechSynthesisUtterance();
speech.lang = 'en';
/*
let voices = []; 
window.speechSynthesis.onvoiceschanged = () => {

  voices = window.speechSynthesis.getVoices();

  speech.voice = voices[0];

  
  let voiceSelect = document.querySelector("#voices");
  voices.forEach((voice, i) => (voiceSelect.options[i] = new Option(voice.name, i)));
};*/
document.querySelector("#start").addEventListener("click", () => {
    
    speech.text = document.querySelector("btn-group").value;
    window.speechSynthesis.speak(speech);
  });
  /*
  document.querySelector("#cancel").addEventListener("click", () => {
    window.speechSynthesis.cancel();
  });
  */